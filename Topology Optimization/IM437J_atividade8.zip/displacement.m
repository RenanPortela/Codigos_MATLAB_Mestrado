function [ u, freedof ] = displacement( alldof, bc, F, kg )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

    freedof = alldof;

    for k = 1 : size(bc,1)
        freedof(2*bc(k,1)-(2-bc(k,2))) = 0;
    end

    F_aux = sparse(F(logical(freedof),1)); % column & rows elimination

    u = zeros(size(F_aux,1),1);

    kg_aux = sparse(kg(logical(freedof),logical(freedof))); % column & rows elimination

    u(logical(freedof),1) = kg_aux\F_aux; % displacement vector

end

