function [ F ] = force_vector( load, nnodes )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

F = zeros(2*nnodes,1); %load matrix pre-location 
nload = size(load,1); %load quantity

for i = 1:nload
    if load(i,2) == 1
        F(2*load(i,1)-1) = load(i,3);        
    else
        F(2*load(i,1)) = load(i,3);
    end    
end

end

