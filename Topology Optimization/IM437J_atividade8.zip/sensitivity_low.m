function [ alpha ] = sensitivity_low( nel, inci, coord, material, area, phi )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

alpha = zeros(nel,1);

for i = 1:nel
    no1 = inci(i,2); %n� 1 do elemento
    no2 = inci(i,3); %n� 2 do elemento
    
    x1 = coord(no1,2); %coordenada x do ponto 1
    x2 = coord(no2,2); %coordenada x do ponto 2
    
    y1 = coord(no1,3); %coordenada y do ponto 1
    y2 = coord(no2,3); %coordenada y do ponto 2
    
    L = sqrt((x2-x1)^2+(y2-y1)^2); %comprimento da barra
    
    E = material(1); %m�dulo de elasticidade do material
    A = area(inci(i,4)); %�rea do elemento
    
    %% �ngulo da barra em rela��o ao eixo x
    
    if (x2-x1)==0 
        if y2>y1
            beta = 2*atan(1);
        else
            beta = -2*atan(1);
        end
    else
        beta = atan((y2-y1)/(x2-x1));
    end
    
    %% matriz de rigidez do elemento
    
    c = cos(beta);
    s = sin(beta);
   
    dA = 1e-3;
    
    ke = E*(A-dA)/L*[c*c c*s -c*c -c*s;
           c*s s*s -c*s -s*s;
           -c*c -c*s c*c c*s;
           -c*s -s*s c*s s*s];
       
    ke_min = E*A/L*[c*c c*s -c*c -c*s;
           c*s s*s -c*s -s*s;
           -c*c -c*s c*c c*s;
           -c*s -s*s c*s s*s];
       
    dke = ke - ke_min;
       
    loc=[2*no1-1, 2*no1, 2*no2-1, 2*no2]; %matriz de localiza��o da matriz de rigidez local na global
    
    phi_aux = phi(loc,1);
    
    %% alpha
    
    alpha(i,1) = phi_aux'*dke*phi_aux;
      
end

end

