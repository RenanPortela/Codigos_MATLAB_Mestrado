function plot_2D_truss( coord, inci, iter )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

figure('NAME', '2D Truss','NumberTitle','off')
title([ 'Iteração:' num2str(iter) ])
hold on
xlim([-4 5])
ylim([0 11])

for i = 1 : size(inci,1)
    plot(coord(inci(i,2:3),2),coord(inci(i,2:3),3),'LineWidth',inci(i,4))
end

end

