% @university: UNIVERSIDADE ESTADUAL DE CAMPINAS
% @school: FACULDADE DE ENGENHARIA MECANICA
% @module: METODOS DE OTIMIZACAO TOPOLOGICA EVOLUCIONARIA - IM437 J
% @activity: ATIVIDADE 8
%
% @author: DIPL. -ENG RENAN MIRANDA PORTELA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% cleaning

clc; clear; close all

%% input data

mode = 1;
nx = 2; % nodes number in x
ny = 11; % nodes number in y
Lx = 1; % length in x [m]
Ly = 10; % length in y [m]
Lz = 1; % length in z [m]


coordx = linspace(0,Lx,nx); % coordinate in x
coordy = linspace(0,Ly,ny); % coordinate in y
[X,Y] = meshgrid(coordx,coordy);
X = X';
Y = Y';
num = 1:nx*ny; % number of nodes
coord = [num(:),X(:),Y(:)]; % coordinate matrix

nnodes = size(coord,1);

%% incidence matrix

inci = zeros(41,4); % incidence matrix pre-location

iter = 0;
iter_2 = 0;

while iter <= size(inci,1)
    iter_2 = iter_2 + 1;
    for j = 1 : 3
       iter = iter + 1;
       if iter > size(inci,1)
           break;
       end
       inci(iter,:) = [iter, 2*iter_2-1, 2*iter_2-1+j,5];
    end
    iter = iter + 1;
    if iter > size(inci,1)
           break;
    end
    inci(iter,:) = [iter, 2*iter_2, 2*iter_2-1+j,5];
end

nel = size(inci,1);

%% boundary conditions matrix

bc(1,:) = [1, 1, 0];
bc(2,:) = [1, 2, 0];
bc(3,:) = [2, 2, 0];

%% load matrix

load(1,:) = [nnodes, 2, -1000];
load(2,:) = [nnodes-1, 2, -1000];

%% material matrix
             %E    rho  nu
material = [10e6 1 0.3];  % [Pa] [kg/m2] []

%% geometry matrix
    
area = linspace(0.1,1,10); 

%% force vector

[ F ] = force_vector( load, nnodes );

%% global stiffness matrix

alldof = 1:nnodes*2; % degrees of freedom
iter = 0;
saving_eig_value = zeros(100,1);
conv = 0;
kk = 0;
frequency = zeros(100,4);

while conv == 0

iter = iter + 1; 

kg = zeros(2*nnodes);
kg_geo = zeros(2*nnodes);
    
[ kg ] = global_stiffness_matrix( nel, inci, coord, material, area, kg );

%% displacement

[ u, freedof ] = displacement( alldof, bc, F, kg );

%% global geometric stiffness matrix

[ kg_geo ] = kg_geometric( nel,inci, coord, material, area, kg_geo, u );

kg_aux = sparse(kg(logical(freedof),logical(freedof))); % column & rows elimination

kg_geo_aux = sparse(kg_geo(logical(freedof),logical(freedof))); % column & rows elimination

[eig_vector, eig_value] = eigs(kg_aux, kg_geo_aux,4,'sm');

plot_2D_truss( coord, inci, iter )

eig_value = sum(eig_value);
eig_aux = [eig_value;eig_vector]';
eig_aux = sortrows(eig_aux,1);

frequency(iter,:) = sqrt(eig_value)/(2*pi);

phi(logical(freedof),1) = eig_aux(mode,2:end);
phi_2 = reshape(phi,[2,22]);
phi_2= phi_2';

cood_aux = coord(:,2:3) + phi_2*1.5;

for i = 1 : size(inci,1)
    plot(cood_aux(inci(i,2:3),1),cood_aux(inci(i,2:3),2),'b--x','LineWidth',2)
end

    if mod(iter, 5) == 0
        kk = kk + 1;
        filename = sprintf('atividade_8_%d', kk);
        saveas(gcf,filename,'fig')
        saveas(gcf,filename,'png')
    end

formatSpec = 'Autovalor: %4.2f \n';
fprintf(formatSpec, eig_aux(mode,1));

saving_eig_value(iter,1) = eig_aux(mode,1);

%% sensitivity

[ alpha ] = sensitivity( nel, inci, coord, material, area, phi );

[alpha, alpha_indice] = sort(alpha);

%% increasing

for i = 1 : 4
    
    increasing = flip(alpha_indice);
    
    if inci(increasing(i,1),4) < 10
    
        inci(increasing(i,1),4) = inci(increasing(i,1),4) + 1;
        
    end
    
end

%% decreasing

[ alpha_low ] = sensitivity_low( nel, inci, coord, material, area, phi );

[alpha, alpha_indice_low] = sort(alpha);

for i = 1 : 4
    
    decreasing = flip(alpha_indice_low);
    
    if inci(decreasing(i,1),4) > 1
    
        inci(decreasing(i,1),4) = inci(decreasing(i,1),4) - 1;
        
    end
    
end


if iter > 1
    
    if saving_eig_value(iter) - saving_eig_value(iter-1) < 0.001

        conv = 1;
    
    end
    
end

end

iter = 1 : iter;

saving_eig_value = saving_eig_value(iter);
figure('Name','Lambda','NumberTitle','off');
plot(iter, saving_eig_value)
grid on
grid minor


kk = kk + 1;
filename = sprintf('atividade_8_%d', kk);
saveas(gcf,filename,'fig')
saveas(gcf,filename,'png')


formatSpec = 'Carga crítica: %4.2f \n';
fprintf(formatSpec, load(1,3)*saving_eig_value(end));

% frequency = frequency(iter,:);
% frequency_1 = frequency(:,1);
% frequency_2 = frequency(:,2);
% frequency_3 = frequency(:,3);
% frequency_4 = frequency(:,4);

% figure('Name','Frequencies','NumberTitle','off');
% ylim([0 5])
% hold on
% plot(iter, frequency_1,'k--')
% plot(iter, frequency_2,'r:')
% plot(iter, frequency_3,'b-^')
% plot(iter, frequency_4,'o')